
library(devtools)
detach(package:gotm)
remove.packages('gotm')
install_github("maciejdanko/gotm")

library(gotm)

#zrobic klasy c('gotm','boot')
#jak wykryje boot to niech liczy CI
#opcja uzycia vgm jako standard
#poprawic wyswietlanie likelihood
#dodac klasyfikacje cutpoints vglm OK


#gotm: Example 1:
model_1<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
               thresh.formula = ~ sex + ageclass,
               data = healthsurvey)
print(model_1)
summary(model_1)
# extract parameters
coef(model_1, aslist = TRUE)
# Robust standard errors based on the sadwitch estimator
summary(model_1, robust.se = TRUE)   #wywalic control z summary

model_1s<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
               thresh.formula = ~ sex + ageclass,
               survey=gotm.design(PWeights=healthsurvey$csw, PSU=healthsurvey$psu),   #dac data w got.design
               data = healthsurvey)
summary(model_1s) #brak gwiazdek
AIC(model_1s) #tutaj stop ani warning

model_2<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
               thresh.formula = ~ ageclass,
               control=list(),
               start = NULL,
               data = healthsurvey,
               hessian=TRUE)

#the significance of the sex as threshold variable
anova(model_2,model_1)

#nie dzialainterakcja
healthsurvey$interaction <- interaction(healthsurvey$ageclass,healthsurvey$sex)
model_3<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
               thresh.formula = ~ ageclass + sex + interaction,
               control=list(),
               start = NULL,
               data = healthsurvey,
               hessian=TRUE)

#pokazac re klasyfikacje by cutpoints jurgesa i modelu, dlaczego klasyfikacja modelu nie moze byc mniejsza od zera
table(model_1$y_i,model_1$Ey_i)

#disabilityweights: Example 1
model_1<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
              thresh.formula = ~ sex + ageclass,
              control=list(),
              start = NULL,
              data = healthsurvey,
              hessian=TRUE)

(disabilityweights(model_1, plotf = TRUE))
(disabilityweights(model_1, plotf = TRUE, namesf=function(x) substr(x, 1, nchar(x)-3)))
(disabilityweights(model_1, plotf = TRUE, namesf=function(x) substr(x, 1, nchar(x)-3), plotpval = TRUE))
(disabilityweights(model_1, plotf = TRUE, namesf=paste('H',1:5,sep='_')))


healthindex(model_1,plotf = TRUE)
