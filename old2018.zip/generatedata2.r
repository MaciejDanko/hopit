library(Rcpp)
library(RcppEigen)
library(VGAM)
library(numDeriv)
library(survey)
library(gotm)

load(file='/home/maciej/Documents/R-PRJ/SHAREfree/WAVE1.rd')
# source('/home/maciej/Documents/R-PRJ/gotm/R/gotm_imprv.r')
# sourceCpp("/home/maciej/Documents/R-PRJ/gotm/src/gotm_c.cpp")
# source('/home/maciej/Documents/R-PRJ/gotm/R/reportingstyles.r')

rm(data)
datae=WAVE1

datae$poor_mobility_or_grip<-c('no','yes')[1+(c(datae$imp.mobility=='poor' | datae$gsable=='unable'))]
datae$heart_stroke_respiratory<-c('no','yes')[1+(datae$heartattack=='yes' | datae$stroke=='yes'| datae$respiratory=='yes')]
table(datae$cholesterol)
reg <- datae[,c('hypertenssion','cholesterol','heart_stroke_respiratory','poor_mobility_or_grip','depression','imp.gender','imp.ageclass')]
apply(reg,2,table)

uuu <- c('hypertenssion','cholesterol','heart_stroke_respiratory','poor_mobility_or_grip','depression','sex','ageclass')
colnames(reg)<-uuu
reg <- apply(reg,2,as.factor)
cTab<-t(table(datae$imp.health,apply(reg,1,paste,sep='',collapse='_')))
datae$imp.health
pTab<-t(apply(cTab,1,function(k) lowess(x=k,f=1)$y))
minv <- 0.01
pTab[pTab<minv]=minv
var.probs<-rowSums(pTab)/sum(pTab) #case probabilities
res.probs<-t(apply(pTab,1,function(k) k/sum(k))) #conditional probability

cP=c(0,cumsum(var.probs))
cP_1=cumsum(var.probs)
cP_2=cP[-length(cP)]
#cP[1:6]
#k=0.095
#which((k<cP_1)&(k>=cP_2))

set.seed(2)  #2 ok

N=10000
Nr=runif(N)
DRAW=sapply(Nr,function(k) which((k<cP_1)&(k>=cP_2)))
length(DRAW)
decodeName<-function(x) {
  z<-gregexpr(pattern = '_', x,fixed=TRUE)
  regmatches(x,z,invert=TRUE)
}
newreg=t(sapply(decodeName(names(DRAW)),unlist))
colnames(newreg)=colnames(reg)
newreg=as.data.frame(newreg)

table(newreg$imp.gender)

TP=res.probs[DRAW,]
cTP=t(apply(TP,1,function(k) c(0,cumsum(k))))
cTP_1=cTP[,-1]
cTP_2=cTP[,-6]
Nr=runif(N)
DRAW2=sapply(seq_along(Nr),function(k) which((Nr[k]<cTP_1[k,])&(Nr[k]>=cTP_2[k,])))

healthd=factor(levels(datae$imp.health)[DRAW2],levels=levels(datae$imp.health))
newdata=as.data.frame(cbind(ID=1:1000, health=healthd, newreg))
newdata$csw=round(sample(datae$csw,N)+Nr*10,2)
newdata$psu=LETTERS[sample(1:5,N,replace=TRUE)]
head(newdata)

###############################################
#test
###############################################

healthsurvey = newdata
healthsurvey$health
dim(newdata)

save(healthsurvey,file='~/Documents/R-PRJ/gotm/data/healthsurvey.rda')
library(VGAM)

DIR='/home/maciej/Documents/R-PRJ/SHAREfree/'
source('/home/maciej/Documents/R-PRJ/gotm/R/gotm_imprv.r')
sourceCpp("/home/maciej/Documents/R-PRJ/gotm/src/gotm_c.cpp")
setwd(DIR)
source('/home/maciej/Documents/R-PRJ/gotm/R/reportingstyles.r')
my.grad <- function(fn, par, eps, ...){
  sapply(1L : length(par), function(k){
    epsi <- rep(0L, length(par))
    epsi[k] <- eps
    (fn(par + epsi, ...) - fn(par - epsi, ...))/2/eps
  })
}


model_1<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
              thresh.formula = ~ sex,
              method = 'exp',#linear zamiast vglm
              control=list(quick.fit=FALSE, max.reiter=1),
              start = NULL,
              data = healthsurvey,
              hessian=TRUE)
model=model_1;
use_weights = TRUE
link <- gotm_c_link(model)
LLfn <- function(par, neg=1, m, model) LLFunc(par, yi=as.numeric(unclass(model$y_i)),reg_mm=model$reg.mm, thresh_mm=model$thresh.mm, parcount=model$parcount,
                                              link=link, thresh_no_cov=model$thresh.no.cov*1, negative=neg, thresh_1_exp = model$control$thresh.1.exp,
                                              weights=model$weights,use_weights = use_weights*1, thresh_start=model$control$thresh.start,
                                              out_val = model$control$LL_out_val, method = m)
LLgr <- function(par, neg=1, m, model) LLGradFunc(par, yi=as.numeric(unclass(model$y_i)), YYY1=model$YYY1, YYY2=model$YYY2,YYY3=model$YYY3[,-model$J],YYY4=model$YYY3[,-1],
                                                  reg_mm=model$reg.mm, thresh_mm=model$thresh.mm, thresh_extd=model$thresh.extd, parcount=model$parcount,
                                                  link=link,thresh_no_cov=model$thresh.no.cov*1, negative=neg, thresh_1_exp = model$control$thresh.1.exp,
                                                  weights=model$weights, thresh_start=model$control$thresh.start, use_weights = use_weights*1,method = m)

A=model_1$vglm.start.ls
B=coef(model_1,aslist=TRUE)

LLfn(model_1$coef,m=0,model = model_1)
LLfn(c(model_1$vglm.start.ls$reg.params, model_1$vglm.start.ls$thresh.lambda, model_1$vglm.start.ls$thresh.gamma),m=1,model = model_1)

cbind(LLgr(model_1$coef,m=0,model = model_1,neg=0),
my.grad(fn=function(x) LLfn(x,m=0,model = model_1, neg=0), par=model_1$coef, eps=1e-5))

LLgr(c(model_1$vglm.start.ls$reg.params, model_1$vglm.start.ls$thresh.lambda, model_1$vglm.start.ls$thresh.gamma),m=1,model = model_1)



x=c(model_1$vglm.start.ls$reg.params, model_1$vglm.start.ls$thresh.lambda, model_1$vglm.start.ls$thresh.gamma)
1000*cbind(my.grad(fn=function(x) LLfn(x,m=1,model = model_1,neg=0), par=x, eps=1e-5)[1:13],
t(LLgr(c(model_1$vglm.start.ls$reg.params, model_1$vglm.start.ls$thresh.lambda, model_1$vglm.start.ls$thresh.gamma),m=1,model = model_1,neg=0))[1:13])

sum()


VgetThresholds(model_1$thresh.mm, A$thresh.lambda, A$thresh.gamma, FALSE, -Inf)[1:6,]
getThresholds(model_1$thresh.mm, B$thresh.lambda, B$thresh.gamma, FALSE, -Inf, FALSE)[1:6,]


z <- vglm2gotm(A$reg.params, A$thresh.lambda, A$thresh.gamma, thresh_1_exp = FALSE)#, (thresh.method != 'jurges')*1)
z$thresh_gamma
B$thresh.gamma

diff1<-function(x) c(x[1],diff(x))

ThreshB=cumsum(c(B$thresh.lambda[1]+B$thresh.gamma[1], exp(B$thresh.lambda[-1]+B$thresh.gamma[-1])))
ThreshA=A$thresh.lambda+A$thresh.gamma

diff(A$thresh.lambda)+diff(A$thresh.gamma)
exp(B$thresh.lambda[-1]+B$thresh.gamma[-1])

log(diff(A$thresh.lambda)+diff(A$thresh.gamma))-B$thresh.lambda[-1]
B$thresh.gamma[-1]

#dA+dB = exp(A + B)

ThreshA
ThreshB



p <- gotm_ExtractParameters(model, parameters)

if (method==1) {
  a =  VgetThresholds(model$thresh.mm,p$thresh.lambda, p$thresh.gamma,0,-Inf)
  b <- - gotm_Latent(p$reg.params, model)

} else {
  a <- gotm_Threshold(p$thresh.lambda, p$thresh.gamma, model)
  b <- gotm_Latent(p$reg.params, model)
}
y <- as.numeric(unclass(model$y_i))
A2 <- pmax(col_path(a, y) - b, -20L)
A1 <- pmin(col_path(a, y + 1) - b, 20L)

lLam <-length(p$thresh.lambda)

P1 <- pnorm(A1)
P2 <- pnorm(A2)
D1 <- dnorm(A1)
D2 <- dnorm(A2)
D <- D1 - D2
P <- P1 - P2

dlnLL_dX <- 1/P



dY <- Vector2DummyMat(y)
YY2 <- (1-cumsum_row(dY))
YY1 <- YY2 + dY
YY2 <- YY2 + dY * (y == NCOL(YY1))
YY1 <- YY1[, -NCOL(YY1)]
YY2 <- YY2[, -NCOL(YY1)]
YY1bound <- matrix(1 * (y!=max(y)), model$N, lLam) * YY1
YY2bound <- matrix(1 * (y!=1), model$N, lLam) * YY2


tmp=matrix(dlnLL_dX, model$N, lLam) * (matrix(D1, model$N, lLam)*dY[,-5] - matrix(D2, model$N, lLam)*dY[,-1])
colSums(tmp)
my.grad(fn=function(x) LLfn(x,m=1,model = model_1,neg=0), par=x, eps=1e-5)[6:9]


tmp=dY[,-5] * matrix(dlnLL_dX, model$N, lLam) * matrix(D1, model$N, lLam)
colSums(tmp)


tmp=dY2[,-1] * matrix(dlnLL_dX, model$N, lLam) * matrix(D1, model$N, lLam)
colSums(tmp)


if (identical(deparse(model$control$thresh.fun), deparse(identity))){
  da <- 1
} else {
  dm <- rep(1,model$N) # dm <- a[,1]
  da <- cbind(dm, t(apply(as.matrix(a[, -c(1, NCOL(a))]), 1, diff)))
}
da1 <- da * YY1
da2 <- da * YY2
D1_ <- matrix(D1, model$N, lLam)
D2_ <- matrix(D2, model$N, lLam)
dlnLL_Lambda <- (D1_ * da1 - D2_ * da2) * matrix(dlnLL_dX, model$N, lLam)
colSums(dlnLL_Lambda)


