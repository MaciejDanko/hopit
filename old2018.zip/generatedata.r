library(Rcpp)
library(RcppEigen)
library(VGAM)
library(numDeriv)
library(survey)
library(gotm)

load(file='/home/maciej/Documents/R-PRJ/SHAREfree/WAVE1.rd')
# source('/home/maciej/Documents/R-PRJ/gotm/R/gotm_imprv.r')
# sourceCpp("/home/maciej/Documents/R-PRJ/gotm/src/gotm_c.cpp")
# source('/home/maciej/Documents/R-PRJ/gotm/R/reportingstyles.r')

rm(data)
datae=WAVE1

datae$poor_mobility_or_grip<-c('no','yes')[1+(c(datae$imp.mobility=='poor' | datae$gsable=='unable'))]
datae$heart_stroke_respiratory<-c('no','yes')[1+(datae$heartattack=='yes' | datae$stroke=='yes'| datae$respiratory=='yes')]
table(datae$cholesterol)
reg <- datae[,c('hypertenssion','cholesterol','heart_stroke_respiratory','poor_mobility_or_grip','depression','imp.gender','imp.ageclass')]
apply(reg,2,table)

uuu <- c('hypertenssion','cholesterol','heart_stroke_respiratory','poor_mobility_or_grip','depression','sex','ageclass')
colnames(reg)<-uuu
reg <- apply(reg,2,as.factor)
cTab<-t(table(datae$imp.health,apply(reg,1,paste,sep='',collapse='_')))
datae$imp.health
pTab<-t(apply(cTab,1,function(k) lowess(x=k,f=1)$y))
minv <- 0.01
pTab[pTab<minv]=minv
var.probs<-rowSums(pTab)/sum(pTab) #case probabilities
res.probs<-t(apply(pTab,1,function(k) k/sum(k))) #conditional probability

cP=c(0,cumsum(var.probs))
cP_1=cumsum(var.probs)
cP_2=cP[-length(cP)]
#cP[1:6]
#k=0.095
#which((k<cP_1)&(k>=cP_2))

set.seed(2)  #2 ok

N=10000
Nr=runif(N)
DRAW=sapply(Nr,function(k) which((k<cP_1)&(k>=cP_2)))
length(DRAW)
decodeName<-function(x) {
  z<-gregexpr(pattern = '_', x,fixed=TRUE)
  regmatches(x,z,invert=TRUE)
}
newreg=t(sapply(decodeName(names(DRAW)),unlist))
colnames(newreg)=colnames(reg)
newreg=as.data.frame(newreg)

table(newreg$imp.gender)

TP=res.probs[DRAW,]
cTP=t(apply(TP,1,function(k) c(0,cumsum(k))))
cTP_1=cTP[,-1]
cTP_2=cTP[,-6]
Nr=runif(N)
DRAW2=sapply(seq_along(Nr),function(k) which((Nr[k]<cTP_1[k,])&(Nr[k]>=cTP_2[k,])))

healthd=factor(levels(datae$imp.health)[DRAW2],levels=levels(datae$imp.health))
newdata=as.data.frame(cbind(ID=1:1000, health=healthd, newreg))
newdata$csw=round(sample(datae$csw,N)+Nr*10,2)
newdata$psu=LETTERS[sample(1:5,N,replace=TRUE)]
head(newdata)

###############################################
#test
###############################################

healthsurvey = newdata
dim(newdata)

save(healthsurvey,file='healthsurvey.rda')
library(VGAM)

# model_1<- gotm(reg.formula = health ~ hypertenssion + cholesterol + heart_stroke_respiratory + poor_mobility_or_grip + depression,
#               thresh.formula = ~ sex + ageclass,
#               control=list(),
#               start = NULL,
#               data = newdata,
#               hessian=TRUE)
#
# d=disabilityweights(model_1,plotf = TRUE)
